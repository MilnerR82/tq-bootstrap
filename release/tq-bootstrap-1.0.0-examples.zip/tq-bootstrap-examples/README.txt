TQ Bootstrap 1.0.0 examples

Includes all 40 native Bootstrap standalone example pages with TQ colours and the documented accessibility corrections, their shared local framework/assets, and their source templates. Preserve this folder structure: the native pages use /docs/5.3 asset URLs. Run node scripts/serve.mjs from this directory and open http://127.0.0.1:5198/docs/5.3/examples/album/ (or another example directory).

This compact download contains examples, not the entire documentation website. General documentation links, hosted Chart.js/maps/services and external media retain their upstream network requirements. The complete website is supplied in tq-bootstrap-1.0.0.zip.
