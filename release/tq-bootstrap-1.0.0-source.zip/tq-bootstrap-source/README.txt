TQ Bootstrap 1.0.0 framework and documentation source

Includes the TQ colour tokens, separate accessibility companion source, complete original Bootstrap 5.3.8 npm package, documentation source/data/static assets, both pinned dependency locks, and the framework/documentation build helpers. With Node.js 22 or newer, run these commands from this directory:

  npm ci --no-audit --no-fund
  node scripts/build.mjs
  npm --prefix docs-source ci --ignore-scripts --no-audit --no-fund
  node docs-source/build-tq-docs.mjs
  node scripts/publish-docs.mjs
  node scripts/serve.mjs

Open http://127.0.0.1:5198/. Dependency installation requires a network connection. The framework build creates dist; the documentation build creates docs-source/site/dist with all native pages and the three independent downloads. Publishing copies that website to this directory for preview. Native hosted services retain their original network requirements.

Generated output, dependency folders, caches and ZIPs are excluded from this source archive. Rebuilding its downloads uses explicit source paths and does not embed generated archives recursively. QA acceptance datasets, upstream acquisition/provenance archives and audit tooling mentioned by shared package metadata or maintainer notes are supplied in the separate complete tq-bootstrap-1.0.0.zip release.
